<?php
defined('ABSPATH') || exit;

class BWDPR {

    const USD_META = '_bwdpr_usd_price';
    const MANAGED_META = '_bwdpr_managed';
    const LAST_PRICE_META = '_bwdpr_last_irr_price';

    public static function init() {
        if (!class_exists('WooCommerce')) {
            return;
        }

        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('woocommerce_product_options_pricing', array(__CLASS__, 'simple_product_field'));
        add_action('woocommerce_process_product_meta', array(__CLASS__, 'save_simple_product'));
        add_action('woocommerce_variation_options_pricing', array(__CLASS__, 'variation_field'), 10, 3);
        add_action('woocommerce_save_product_variation', array(__CLASS__, 'save_variation'), 10, 2);
        add_action(BWDPR_CRON_HOOK, array(__CLASS__, 'update_all'));
        add_action('admin_post_bwdpr_manual_update', array(__CLASS__, 'manual_update'));

        add_filter('plugin_action_links_' . plugin_basename(BWDPR_FILE), array(__CLASS__, 'plugin_action_links'));
    }

    public static function activate() {
        if (!wp_next_scheduled(BWDPR_CRON_HOOK)) {
            wp_schedule_event(time() + 300, 'hourly', BWDPR_CRON_HOOK);
        }
        if (!get_option(BWDPR_OPTION)) {
            add_option(BWDPR_OPTION, array(
                'endpoint' => 'https://api.bitpin.org/v1/mkt/tickers/',
                'symbol' => 'USDT_IRT',
                'api_unit' => 'toman',
                'adjust_percent' => '0',
                'round_to' => '1000',
                'timeout' => '15',
            ));
        }
    }

    public static function deactivate() {
        $timestamp = wp_next_scheduled(BWDPR_CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, BWDPR_CRON_HOOK);
        }
    }

    public static function plugin_action_links($links) {
        $url = admin_url('admin.php?page=bwdpr');
        array_unshift($links, '<a href="' . esc_url($url) . '">تنظیمات</a>');
        return $links;
    }

    public static function settings() {
        $defaults = array(
            'endpoint' => 'https://api.bitpin.org/v1/mkt/tickers/',
            'symbol' => 'USDT_IRT',
            'api_unit' => 'toman',
            'adjust_percent' => '0',
            'round_to' => '1000',
            'timeout' => '15',
        );
        return wp_parse_args((array) get_option(BWDPR_OPTION, array()), $defaults);
    }

    public static function register_settings() {
        register_setting('bwdpr_settings_group', BWDPR_OPTION, array(
            'type' => 'array',
            'sanitize_callback' => array(__CLASS__, 'sanitize_settings'),
        ));
    }

    public static function sanitize_settings($input) {
        $s = self::settings();
        $output = array();
        $output['endpoint'] = !empty($input['endpoint']) ? esc_url_raw($input['endpoint']) : $s['endpoint'];
        $output['symbol'] = !empty($input['symbol']) ? sanitize_text_field($input['symbol']) : 'USDT_IRT';
        $output['api_unit'] = in_array($input['api_unit'] ?? 'toman', array('toman', 'rial'), true) ? $input['api_unit'] : 'toman';
        $output['adjust_percent'] = isset($input['adjust_percent']) ? (float) $input['adjust_percent'] : 0;
        $output['round_to'] = max(1, (int) ($input['round_to'] ?? 1000));
        $output['timeout'] = min(60, max(5, (int) ($input['timeout'] ?? 15)));
        return $output;
    }

    public static function admin_menu() {
        add_submenu_page(
            'woocommerce',
            'قیمت‌گذاری دلاری بیت‌پین',
            'قیمت‌گذاری دلاری',
            'manage_woocommerce',
            'bwdpr',
            array(__CLASS__, 'settings_page')
        );
    }

    public static function settings_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }
        $s = self::settings();
        $last_rate = get_option('bwdpr_last_rate');
        $last_time = get_option('bwdpr_last_update');
        $last_error = get_option('bwdpr_last_error');
        ?>
        <div class="wrap" dir="rtl">
            <h1>قیمت‌گذاری دلاری با Bitpin</h1>
            <p>اگر برای یک محصول یا متغیر آن قیمت دلاری وارد شود، قیمت تومان آن از نرخ Bitpin محاسبه و هر ساعت به‌روزرسانی می‌شود.</p>

            <div style="background:#fff;border:1px solid #ddd;padding:16px;margin:15px 0;max-width:900px">
                <h2 style="margin-top:0">وضعیت</h2>
                <p><strong>نرخ فعلی ذخیره‌شده:</strong>
                    <?php echo $last_rate !== false ? esc_html(number_format_i18n((float)$last_rate, 0)) . ' تومان' : 'هنوز دریافت نشده'; ?>
                </p>
                <p><strong>آخرین بروزرسانی:</strong>
                    <?php echo $last_time ? esc_html(wp_date('Y-m-d H:i:s', (int)$last_time)) : '—'; ?>
                </p>
                <?php if ($last_error): ?>
                    <p style="color:#b32d2e"><strong>آخرین خطا:</strong> <?php echo esc_html($last_error); ?></p>
                <?php endif; ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="bwdpr_manual_update">
                    <?php wp_nonce_field('bwdpr_manual_update'); ?>
                    <button class="button button-primary">دریافت نرخ و بروزرسانی محصولات الان</button>
                </form>
            </div>

            <form method="post" action="options.php" style="background:#fff;border:1px solid #ddd;padding:16px;max-width:900px">
                <?php settings_fields('bwdpr_settings_group'); ?>
                <h2>تنظیمات</h2>
                <table class="form-table">
                    <tr>
                        <th>API Endpoint</th>
                        <td><input type="url" class="regular-text" name="<?php echo esc_attr(BWDPR_OPTION); ?>[endpoint]" value="<?php echo esc_attr($s['endpoint']); ?>"></td>
                    </tr>
                    <tr>
                        <th>Symbol</th>
                        <td>
                            <input type="text" name="<?php echo esc_attr(BWDPR_OPTION); ?>[symbol]" value="<?php echo esc_attr($s['symbol']); ?>">
                            <p class="description">به‌صورت پیش‌فرض USDT_IRT است.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>واحد نرخ API</th>
                        <td>
                            <select name="<?php echo esc_attr(BWDPR_OPTION); ?>[api_unit]">
                                <option value="toman" <?php selected($s['api_unit'], 'toman'); ?>>تومان</option>
                                <option value="rial" <?php selected($s['api_unit'], 'rial'); ?>>ریال (به تومان تبدیل شود)</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>تعدیل قیمت (%)</th>
                        <td>
                            <input type="number" step="0.01" name="<?php echo esc_attr(BWDPR_OPTION); ?>[adjust_percent]" value="<?php echo esc_attr($s['adjust_percent']); ?>">
                            <p class="description">مثلاً 10 یعنی 10٪ به قیمت ارزی اضافه شود. برای کسر 5٪ مقدار -5 وارد کنید.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>گرد کردن قیمت</th>
                        <td>
                            <input type="number" min="1" step="1" name="<?php echo esc_attr(BWDPR_OPTION); ?>[round_to]" value="<?php echo esc_attr($s['round_to']); ?>">
                            <p class="description">مثلاً 1000 یعنی 543271 به 543000 گرد می‌شود.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Timeout API</th>
                        <td><input type="number" min="5" max="60" name="<?php echo esc_attr(BWDPR_OPTION); ?>[timeout]" value="<?php echo esc_attr($s['timeout']); ?>"> ثانیه</td>
                    </tr>
                </table>
                <?php submit_button('ذخیره تنظیمات'); ?>
            </form>

            <div style="background:#f6f7f7;border-right:4px solid #2271b1;padding:12px;margin-top:15px;max-width:900px">
                <strong>نحوه استفاده:</strong>
                <ol>
                    <li>محصول را ویرایش کنید.</li>
                    <li>در بخش اطلاعات محصول، قیمت دلاری را وارد کنید.</li>
                    <li>برای محصول متغیر، قیمت دلاری را روی هر Variation موردنظر وارد کنید.</li>
                    <li>اگر این فیلد خالی باشد، افزونه قیمت آن مورد را تغییر نمی‌دهد.</li>
                    <li>قیمت‌ها هر ساعت از Bitpin به‌روزرسانی می‌شوند.</li>
                </ol>
            </div>
        </div>
        <?php
    }

    public static function simple_product_field() {
        global $post;
        $product = wc_get_product($post->ID);
        if (!$product) return;
        $value = get_post_meta($post->ID, self::USD_META, true);
        ?>
        <div class="options_group">
            <p class="form-field">
                <label for="bwdpr_usd_price">قیمت ثابت دلاری</label>
                <input type="number" class="short" step="0.000001" min="0" name="bwdpr_usd_price" id="bwdpr_usd_price" value="<?php echo esc_attr($value); ?>" placeholder="مثلاً 5.99">
                <span class="description">اگر پر شود، قیمت تومان این محصول طبق نرخ Bitpin محاسبه می‌شود. خالی = بدون مدیریت دلاری.</span>
            </p>
        </div>
        <?php
    }

    public static function save_simple_product($post_id) {
        if (!isset($_POST['woocommerce_meta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['woocommerce_meta_nonce'])), 'woocommerce_save_data')) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) return;

        $value = isset($_POST['bwdpr_usd_price']) ? wc_format_decimal(wp_unslash($_POST['bwdpr_usd_price']), 6) : '';
        if ($value !== '') {
            update_post_meta($post_id, self::USD_META, $value);
            update_post_meta($post_id, self::MANAGED_META, 'yes');
        } else {
            delete_post_meta($post_id, self::USD_META);
            delete_post_meta($post_id, self::MANAGED_META);
        }
    }

    public static function variation_field($loop, $variation_data, $variation) {
        $value = get_post_meta($variation->ID, self::USD_META, true);
        ?>
        <p class="form-row form-row-full">
            <label>قیمت ثابت دلاری این متغیر</label>
            <input type="number" step="0.000001" min="0" class="short" name="bwdpr_variation_usd_price[<?php echo esc_attr($loop); ?>]" value="<?php echo esc_attr($value); ?>" placeholder="مثلاً 5.99">
            <span class="description">اگر پر شود، قیمت Regular این Variation از روی نرخ Bitpin محاسبه می‌شود. خالی = بدون مدیریت دلاری.</span>
        </p>
        <?php
    }

    public static function save_variation($variation_id, $i) {
        if (!current_user_can('edit_post', $variation_id)) return;
        $value = isset($_POST['bwdpr_variation_usd_price'][$i])
            ? wc_format_decimal(wp_unslash($_POST['bwdpr_variation_usd_price'][$i]), 6)
            : '';

        if ($value !== '') {
            update_post_meta($variation_id, self::USD_META, $value);
            update_post_meta($variation_id, self::MANAGED_META, 'yes');
        } else {
            delete_post_meta($variation_id, self::USD_META);
            delete_post_meta($variation_id, self::MANAGED_META);
        }
    }

    public static function manual_update() {
        if (!current_user_can('manage_woocommerce')) wp_die('دسترسی غیرمجاز');
        check_admin_referer('bwdpr_manual_update');

        $result = self::update_all(true);
        $url = add_query_arg(
            array('page' => 'bwdpr', 'bwdpr_result' => $result['success'] ? 'success' : 'error'),
            admin_url('admin.php')
        );
        if (!$result['success']) {
            $url = add_query_arg('bwdpr_msg', rawurlencode($result['message']), $url);
        }
        wp_safe_redirect($url);
        exit;
    }

    private static function fetch_rate() {
        $s = self::settings();
        $response = wp_remote_get($s['endpoint'], array(
            'timeout' => $s['timeout'],
            'headers' => array('Accept' => 'application/json'),
            'user-agent' => 'Bitpin-WooCommerce-Dollar-Pricer/' . BWDPR_VERSION . '; ' . home_url('/'),
        ));

        if (is_wp_error($response)) {
            throw new Exception('خطای اتصال به API: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        if ($code < 200 || $code >= 300) {
            throw new Exception('API با کد HTTP ' . $code . ' پاسخ داد.');
        }

        $data = json_decode($body, true);
        if (!is_array($data)) {
            throw new Exception('پاسخ API معتبر نیست.');
        }

        $symbol = strtoupper(trim($s['symbol']));
        $rate = self::extract_rate($data, $symbol);

        if ($rate <= 0) {
            throw new Exception('قیمت نماد ' . $symbol . ' در پاسخ API پیدا نشد.');
        }

        if ($s['api_unit'] === 'rial') {
            $rate = $rate / 10;
        }

        return (float) $rate;
    }

    private static function extract_rate($data, $symbol) {
        $items = null;
        if (isset($data['results']) && is_array($data['results'])) {
            $items = $data['results'];
        } elseif (is_array($data) && isset($data[0])) {
            $items = $data;
        }

        if ($items) {
            foreach ($items as $item) {
                $item_symbol = '';
                foreach (array('symbol', 'code', 'market', 'pair') as $key) {
                    if (isset($item[$key]) && is_string($item[$key])) {
                        $item_symbol = strtoupper($item[$key]);
                        break;
                    }
                }
                if ($item_symbol === $symbol) {
                    foreach (array('price', 'last_price', 'last', 'close') as $key) {
                        if (isset($item[$key]) && is_numeric($item[$key])) return (float) $item[$key];
                    }
                }
            }
        }

        if (is_array($data)) {
            foreach ($data as $key => $value) {
                if (is_string($key) && strtoupper($key) === $symbol && is_array($value)) {
                    foreach (array('price', 'last_price', 'last', 'close') as $p) {
                        if (isset($value[$p]) && is_numeric($value[$p])) return (float) $value[$p];
                    }
                }
                if (is_array($value)) {
                    $found = self::extract_rate($value, $symbol);
                    if ($found > 0) return $found;
                }
            }
        }

        return 0;
    }

    public static function update_all($manual = false) {
        if (!class_exists('WooCommerce')) {
            return array('success' => false, 'message' => 'WooCommerce فعال نیست.');
        }

        try {
            $rate = self::fetch_rate();
            update_option('bwdpr_last_rate', $rate, false);
            update_option('bwdpr_last_update', time(), false);
            delete_option('bwdpr_last_error');

            $s = self::settings();
            $updated = 0;

            $products = get_posts(array(
                'post_type' => 'product',
                'post_status' => array('publish', 'private', 'draft'),
                'posts_per_page' => -1,
                'fields' => 'ids',
                'meta_query' => array(
                    array(
                        'key' => self::USD_META,
                        'value' => '',
                        'compare' => '!=',
                    )
                )
            ));

            foreach ($products as $product_id) {
                if (self::update_product_price($product_id, $rate, $s)) {
                    $updated++;
                }
            }

            $variations = get_posts(array(
                'post_type' => 'product_variation',
                'post_status' => array('publish', 'private'),
                'posts_per_page' => -1,
                'fields' => 'ids',
                'meta_query' => array(
                    array(
                        'key' => self::USD_META,
                        'value' => '',
                        'compare' => '!=',
                    )
                )
            ));

            foreach ($variations as $variation_id) {
                if (self::update_product_price($variation_id, $rate, $s)) {
                    $updated++;
                }
            }

            return array(
                'success' => true,
                'message' => 'نرخ دریافت شد و ' . $updated . ' مورد به‌روزرسانی شد.',
            );
        } catch (Exception $e) {
            update_option('bwdpr_last_error', $e->getMessage(), false);
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    private static function update_product_price($post_id, $rate, $settings) {
        $usd = get_post_meta($post_id, self::USD_META, true);
        if ($usd === '' || !is_numeric($usd) || (float)$usd < 0) return false;

        $price = (float)$usd * (float)$rate;
        $adjust = (float)$settings['adjust_percent'];
        if ($adjust != 0) {
            $price *= (1 + ($adjust / 100));
        }

        $round = max(1, (int)$settings['round_to']);
        $price = round($price / $round) * $round;

        $product = wc_get_product($post_id);
        if (!$product) return false;

        // Preserve the USD source in meta; only change WooCommerce's regular price.
        $product->set_regular_price((string)$price);

        // If a sale price is active and managed separately, do not overwrite it.
        // For managed USD items, remove a sale price so regular price is the effective price.
        if ($product->get_sale_price() !== '') {
            $product->set_sale_price('');
        }

        $product->save();
        update_post_meta($post_id, self::LAST_PRICE_META, $price);
        return true;
    }
}
