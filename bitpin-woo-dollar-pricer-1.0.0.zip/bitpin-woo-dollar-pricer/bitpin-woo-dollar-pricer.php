<?php
/**
 * Plugin Name: Bitpin WooCommerce Dollar Pricing
 * Description: Automatically prices selected WooCommerce products/variations from a fixed USD price using Bitpin USDT/IRT market rate.
 * Version: 1.0.0
 * Author: Custom
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Text Domain: bitpin-woo-dollar-pricer
 * CopyRight = @asrnovin_ir / @aminiyt
 * full Free
 */

defined('ABSPATH') || exit;

define('BWDPR_VERSION', '1.0.0');
define('BWDPR_FILE', __FILE__);
define('BWDPR_DIR', plugin_dir_path(__FILE__));
define('BWDPR_OPTION', 'bwdpr_settings');
define('BWDPR_CRON_HOOK', 'bwdpr_hourly_update');

require_once BWDPR_DIR . 'includes/class-bwdpr.php';

register_activation_hook(__FILE__, array('BWDPR', 'activate'));
register_deactivation_hook(__FILE__, array('BWDPR', 'deactivate'));

add_action('plugins_loaded', array('BWDPR', 'init'));
